function ouvrirRegles(){
	document.getElementById("regles_popup").style.display="block";
}

function ouvrirInscription(){
	document.getElementById("inscription_popup").style.display="block";
}

function ouvrirConnexion(){
	document.getElementById("connexion_popup").style.display="block";
}

function revenirPageAccueil(){
	document.location.href = "accueil.html";
}
