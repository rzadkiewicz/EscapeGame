function ouvrirRegles(){
	document.getElementById("regles_popup").style.display="block";
}

function ouvrirInscription(){
	document.getElementById("inscription_popup").style.display="block";
}

function ouvrirConnexion(){
	document.getElementById("connexion_popup").style.display="block";
}

function revenirPageAccueil(){
	document.location.href = "accueil.html";
}

function verifMDP(saisie){
	if( saisie.MDP.value == '' || saisie.VMDP.value == ''){
		alert ('Les champs ne sont pas remplis');
		saisie.MDP.focus();
		return false;
	} else if (saisie.MDP.value != saisie.VMDP.value) {
		alert ('Les mots de passes ne sont pas identiques')
		saisie.MDP.focus();
		return false
	} else if (saisie.MDP.value == saisie.VMDP.value) {
		return true;
	} else {
		saisie.MDP.focus();
	}

}
