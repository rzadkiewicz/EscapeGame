var btn = document.querySelector('button');

function SalleFinie() {

	btn.addEventListener('click', event => {

		var x = document.getElementById('cadenas');
		var v = x.getAttribute("src");
		if(v == "Salle/cadenas.png")
			v = "SalleFinie/cadenasOuvert.png";
		x.setAttribute("src", v);

		var x = document.getElementById('bonhomme');
		var v = x.getAttribute("src");
		if(v == "Salle/bonhomme.png")
			v = "SalleFinie/BonhommeContent.png";
		x.setAttribute("src", v);


		var img = document.createElement("img");
		img.src = "SalleFinie/sallesuivtxt.png";
		img.style = "left:67%;position:absolute;width: 25%;top: 8%;";
		var div = document.getElementById("bulle");
		div.parentNode.appendChild(img);


		var img = document.createElement("img");
		img.src = "SalleFinie/portail.png";
		img.style = "left: 48%;position: absolute;width: 13%;";
		var div = document.getElementById("porte");
		div.parentNode.appendChild(img);

	});
}


SalleFinie();

                function timer()
                {
            var compteur=document.getElementById('compteur');
            s=duree;
            m=0;h=0;
            if(s<0)
            {
                compteur.innerHTML="perdu<br />"
                document.location.href="gameover.html";
            }
            else{
                if(s>59){
                    m=Math.floor(s/60);
                   	s=s-m*60
                }
                if(m>59){
                    h=Math.floor(m/60);
                    m=m-h*60
                }
                if(s<10){
                    s="0"+s
               	}
                if(m<10){
                    m="0"+m
                }
                compteur.innerHTML=h+":"+m+":"+s
            }
            duree=duree-1;
            window.setTimeout("timer();",1000);
        }


                        duree="15";
                        timer();
