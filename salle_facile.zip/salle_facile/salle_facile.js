var btn = document.querySelector('#valider');

function SalleFinie() {
		var x = document.getElementById('cadenas');
		var v = x.getAttribute("src");
		if(v == "Salle/cadenas.png")
			v = "SalleFinie/cadenasOuvert.png";
		x.setAttribute("src", v);

		var x = document.getElementById('bonhomme');
		var v = x.getAttribute("src");
		if(v == "Salle/bonhomme.png")
			v = "SalleFinie/BonhommeContent.png";
		x.setAttribute("src", v);

		var img = document.createElement("img");
		img.src = "SalleFinie/portail.png";
		img.style = "left: 48%;position: absolute;width: 13%;";
		var div = document.getElementById("porte");
		div.parentNode.appendChild(img);

        var button = document.createElement('a');

        if(document.title == 'salle n°1') button.href = 'salle2.html';
        if(document.title == 'salle n°2') button.href = 'salle3.html';
        if(document.title == 'salle n°3') button.href = 'salle4.html';
        if(document.title == 'salle n°4') button.href = 'salle5.html';        
        button.appendChild(img);

        document.getElementById("porte").parentNode.appendChild(button);
        img.style = "left: 48%;position: absolute;width: 13%;";
}
                
        function timer(){
            var compteur=document.getElementById('compteur');
            s=duree;
            m=0;h=0;
            if(s<0){
                compteur.innerHTML="perdu<br />"
                document.location.href="gameover.html";
            }
            else{
                if(s>59){
                    m=Math.floor(s/60);
                   	s=s-m*60
                }
                if(m>59){
                    h=Math.floor(m/60);
                    m=m-h*60
                }
                if(s<10){
                    s="0"+s
               	}
                if(m<10){
                    m="0"+m
                }
                compteur.innerHTML=h+":"+m+":"+s
            }
            duree=duree-1;
            window.setTimeout("timer();",1000);
        }
        duree="150";
        timer();

var enigmes_fac =
['Que signifie CSS ?',
'Que signifie PHP ?',
'Que signifie PNG ?',
'Que signifie AJAX ?',
'Dans quelle balise se trouve un paragraphe ?',
'En CSS, est-il possible de sélectionner plusieurs éléments différents en même temps?',
'Que signifie " || " ?'
];
var reponses_fac =
['Cascading Style Sheets',
'PHP: Hypertext Preprocessor',
'Portable Network Graphic',
'Asynchronous JavaScript and XML',
'body',
'oui',
'ou'
];
var indices_fac =
['Cascading St..e Sh....',
'PHP: Hypert..t Pre.........',
'Portable Net...k Gr.....',
'Asynchronous Java...... and ...',
'signifie corps en anglais',
'peut-être',
'c est un opérateur de comparaison'
];

var nombre = Math.floor(Math.random() *enigmes_fac.length);

x=enigmes_fac[nombre];

document.getElementById('enigme').innerHTML = x;
document.getElementById('indice-body').innerHTML = indices_fac[nombre];

btn.addEventListener('click', event => {

    var saisie =document.getElementById("reponse").value;
    console.log(saisie);
    console.log(reponses_fac[nombre]);

    if(saisie == reponses_fac[nombre]){
        SalleFinie();
        console.log(enigmes_fac);
        enigme_fac = enigmes_fac.splice(nombre,1);
        reponse_fac = reponses_fac.splice(nombre,1);
        console.log(enigmes_fac);
    }

});

const openIndiceButtons = document.querySelectorAll('[data-indice-target]')
const closeIndiceButtons = document.querySelectorAll('[data-close-button]')

openIndiceButtons.forEach(button => {
  button.addEventListener('click', () => {
    const indice = document.querySelector(button.dataset.indiceTarget)
    openIndice(indice)
  })
})
closeIndiceButtons.forEach(button => {
  button.addEventListener('click', () => {
    const indice = button.closest('.indice')
    closeIndice(indice)
  })
})
function openIndice(indice) {
  if (indice == null) return
  indice.classList.add('active')
  overlay.classList.add('active')
}
function closeIndice(indice) {
  if (indice == null) return
  indice.classList.remove('active')
  overlay.classList.remove('active')
}