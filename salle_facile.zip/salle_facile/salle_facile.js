var btn = document.querySelector('button');

function SalleFinie() {

	btn.addEventListener('click', event => {

		var x = document.getElementById('cadenas');
		var v = x.getAttribute("src");
		if(v == "Salle/cadenas.png")
			v = "SalleFinie/cadenasOuvert.png";
		x.setAttribute("src", v);

		var x = document.getElementById('bonhomme');
		var v = x.getAttribute("src");
		if(v == "Salle/bonhomme.png")
			v = "SalleFinie/BonhommeContent.png";
		x.setAttribute("src", v);

		var img = document.createElement("img");
		img.src = "SalleFinie/portail.png";
		img.style = "left: 48%;position: absolute;width: 13%;";
		var div = document.getElementById("porte");
		div.parentNode.appendChild(img);

	});
}

                function timer()
                {
            var compteur=document.getElementById('compteur');
            s=duree;
            m=0;h=0;
            if(s<0)
            {
                compteur.innerHTML="perdu<br />"
                document.location.href="gameover.html";
            }
            else{
                if(s>59){
                    m=Math.floor(s/60);
                   	s=s-m*60
                }
                if(m>59){
                    h=Math.floor(m/60);
                    m=m-h*60
                }
                if(s<10){
                    s="0"+s
               	}
                if(m<10){
                    m="0"+m
                }
                compteur.innerHTML=h+":"+m+":"+s
            }
            duree=duree-1;
            window.setTimeout("timer();",1000);
        }


        duree="1500";
        timer();



function valider(){
  // si la valeur du champ prenom est non vide
  if(document.formSaisie.prenom.value != "") {
    // les données sont ok, on peut envoyer le formulaire    
    return true;
  }
  else {
    // sinon on affiche un message
    alert("Saisissez le prénom");
    // et on indique de ne pas envoyer le formulaire
    return false;
  }
}