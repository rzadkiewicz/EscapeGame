<?php
session_start();
$idutilisateur=$_SESSION["identifiant"];
$email=$_SESSION["email"];
?>


<?php
$servername = "localhost";
$username = "username";
$password = "password";
//utilise PDO car fonctionne sur 12 systems de bdd differents alors que MySQLi marque que sur MySQL
try {
  $connection = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);
  // set the PDO error mode to exception
  $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connection reussite";
} catch(PDOException $e) {
  echo "Connection échouée: " . $e->getMessage();
}
$connection=null; //pour fermer la connection
?>